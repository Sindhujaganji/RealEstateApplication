public class PurchaseProperty extends Property {
	private double price;
	private double annualTaxes;

	//get and set methods for price
	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	//get and set methods for annual taxes

	public double getAnnualTaxes() {
		return annualTaxes;
	}

	public void setAnnualTaxes(double annualTaxes) {
		this.annualTaxes = annualTaxes;
	}
}