//House inherited from Purchase property(parent)
public class House extends PurchaseProperty {
	public void print() {
		System.out.println("Type : House");
		System.out.println("Address : " + this.getAddress());
		System.out.println("City : " + this.getCity());
		System.out.println("State : " + this.getState());
		System.out.println("Zip Code : " + this.getZipcode());
		System.out.println("No Of Bedrooms : " + this.getNoOfBedrooms());
		System.out.println("No Of Bathrooms : " + this.getNoOfBathrooms());
		System.out.println("Purchase price : " + this.getPrice());
		System.out.println("Annual Taxes : " + this.getAnnualTaxes());
	}
}