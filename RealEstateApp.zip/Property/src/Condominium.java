//condominium inherited from Purchase property(parent)
public class Condominium extends PurchaseProperty {
	private double monthlyFee;

	//get and set methods for monthly fee
	public double getMonthlyFee() {
		return monthlyFee;
	}

	public void setMonthlyFee(double monthlyFee) {
		this.monthlyFee = monthlyFee;
	}

	public void print() {
		System.out.println("Type : Condominium");
		System.out.println("Address : " + this.getAddress());
		System.out.println("City : " + this.getCity());
		System.out.println("State : " + this.getState());
		System.out.println("Zip Code : " + this.getZipcode());
		System.out.println("No Of Bedrooms : " + this.getNoOfBedrooms());
		System.out.println("No Of Bathrooms : " + this.getNoOfBathrooms());
		System.out.println("Purchase price : " + this.getPrice());
		System.out.println("Annual Taxes : " + this.getAnnualTaxes());
		System.out.println("Monthly Fee : " + this.getMonthlyFee());
	}
}