public class Property {
	private String address;
	private String city;
	private String state;
	private String zipcode;
	private int noOfBedrooms;
	private int noOfBathrooms;

	//get and set methods for Address
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	//get and set methods for city
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	//get and set methods for state

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	//get and set methods for zipcode
	public String getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	//get and set methods for No of bedrooms
	public int getNoOfBedrooms() {
		return noOfBedrooms;
	}

	public void setNoOfBedrooms(int noOfBedrooms) {
		this.noOfBedrooms = noOfBedrooms;
	}
	
	//get and set methods for No of bathrooms

	public int getNoOfBathrooms() {
		return noOfBathrooms;
	}

	public void setNoOfBathrooms(int noOfBathrooms) {
		this.noOfBathrooms = noOfBathrooms;
	}
}