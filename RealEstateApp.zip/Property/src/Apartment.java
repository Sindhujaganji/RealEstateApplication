//apartment inherited from Rental property(parent)
public class Apartment extends RentalProperty {
	public void print() { 
		System.out.println("Type : Apartment");
		System.out.println("Address : " + this.getAddress());
		System.out.println("City : " + this.getCity());
		System.out.println("State : " + this.getState());
		System.out.println("Zip Code : " + this.getZipcode());
		System.out.println("No Of Bedrooms : " + this.getNoOfBedrooms());
		System.out.println("No Of Bathrooms : " + this.getNoOfBathrooms());
		System.out.println("Monthly rent : " + this.getMonthlyFee());
		System.out.println("Lease Period : " + this.getLeasePeriod());
	}
}
