public class RentalProperty extends Property {
	private double monthlyFee;
	private int leasePeriod;
	
	//get and set methods for monthly fee

	public double getMonthlyFee() {
		return monthlyFee;
	}

	public void setMonthlyFee(double monthlyFee) {
		this.monthlyFee = monthlyFee;
	}

	//get and set methods for lease period
	public int getLeasePeriod() {
		return leasePeriod;
	}

	public void setLeasePeriod(int leasePeriod) {
		this.leasePeriod = leasePeriod;
	}
}