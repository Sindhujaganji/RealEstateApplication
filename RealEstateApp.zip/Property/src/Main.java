import java.util.LinkedList;
import java.util.List;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) throws Exception {
		boolean setChoice = true;
		boolean setQuit = false;
		
		List<House> listOfHouses = new LinkedList<House>();
		List<Condominium> listOfCondominium = new LinkedList<Condominium>();
		List<Apartment> listOfApartment = new LinkedList<Apartment>();
		
		System.out.println("Sinra Realty Company.");

		System.out.println("Welcome to Real Estate Management Application");

		Scanner input = new Scanner(System.in); // Created a Scanner object
		
		do {
			System.out.println("Choose options :\r\n"+
		                      "A. Create house listing\r\n" + 
					          "B. Create condominium listing\r\n"+ 
		                      "C. Create apartment listing\r\n" +
					          "D. Show listings\r\n" + 
		                      "E. Exit\r\n"+
					          "You can abort and get to main menu anytime by entering 'quit'/'abort'");

			String option = input.nextLine();
			//set confirmation to exit the application
		               if (option.charAt(0) == 'e' || option.charAt(0) == 'E') {
				boolean setConfirmation = false;
				System.out.println("Do you want to exit the program? Press 'Y' for confirmation to exit");
				String confirmation = input.nextLine();
				if (confirmation.charAt(0) == 'y' || confirmation.charAt(0) == 'Y') {
					setConfirmation = true;
				}
				if (setConfirmation) {
					setQuit = true;
					break;
				}
			} else if (option.charAt(0) == 'a' || option.charAt(0) == 'A' || option.charAt(0) == 'b'
					|| option.charAt(0) == 'B' || option.charAt(0) == 'c' || option.charAt(0) == 'C'
					|| option.charAt(0) == 'd' || option.charAt(0) == 'D') {
				
				//prints house properties in show listings
				if (option.charAt(0) == 'd' || option.charAt(0) == 'D') {
					if (listOfHouses.size() > 0) {
						for (House property : listOfHouses) {
							property.print();
							System.out.println("");
						}
					
					} else {
						System.out.println("House records are not found..!");
					}
					System.out.println("************************************");
					//prints condo properties in show listings
					if (listOfCondominium.size() > 0) {
						for (Condominium property : listOfCondominium) {
							property.print();
							System.out.println("");
						}
					} else {
						System.out.println("Condominium records are not found..!");
					}
					System.out.println("***************************************");
					//prints apartment properties in show listings
					if (listOfApartment.size() > 0) {
						for (Apartment property : listOfApartment) {
							property.print();
							System.out.println("");
						}
					} else {
						System.out.println("Apartment records are not found..!");
					}
					System.out.println("********************************************");
				
				} else {
					boolean setAbort = false;
					System.out.println("Enter the address of the property"); // taking address as user input
					String address = input.nextLine();
					if (address.equalsIgnoreCase("quit") || address.equalsIgnoreCase("abort")) {
						setAbort = true;
						continue;
					}

					System.out.println("Enter city where the property is located"); // taking city as user input
					String city = input.nextLine();
					if (city.equalsIgnoreCase("quit") || city.equalsIgnoreCase("abort")) {
						setAbort = true;
						continue;
					}

					System.out.println("Enter state where the property is located"); // taking state as user input
					String state = input.nextLine();
					if (state.equalsIgnoreCase("quit") || state.equalsIgnoreCase("abort")) {
						setAbort = true;
						continue;
					}

					System.out.println("Enter the postal code of the property"); // taking postal code as user input
					String zipcode = input.nextLine();
					if (zipcode.equalsIgnoreCase("quit") || zipcode.equalsIgnoreCase("abort")) {
						setAbort = true;
						continue;
					}
                     
					//to check if user giving correct input 
					
					int noOfBedrooms = 0;
					boolean setNumber = false;
					System.out.println("Enter the number of bedrooms the property has");
					do {
						setNumber = true;
						try {
							String reqInput = input.nextLine();
							if (reqInput.equalsIgnoreCase("quit") || reqInput.equalsIgnoreCase("abort")) {
								setAbort = true;
								break;
							}
							noOfBedrooms = Integer.parseInt(reqInput);
						} catch (Exception e) {
							setNumber = false;
							System.out.println("Incorrect input. Value must be number. Enter again.");
						}
					} while (setNumber != true);
					if (setAbort)
						continue;

					int noOfBathrooms = 0;
					setNumber = false;
					System.out.println("Enter the number of bathrooms the property has");
					do {
						setNumber = true;
						try {
							String reqInput = input.nextLine();
							if (reqInput.equalsIgnoreCase("quit") || reqInput.equalsIgnoreCase("abort")) {
								setAbort = true;
								break;
							}
							noOfBathrooms = Integer.parseInt(reqInput);
						} catch (Exception e) {
							setNumber = false;
							System.out.println("Incorrect input. Value must be number. Enter again.");
						}
					} while (setNumber != true);
					if (setAbort)
						continue;

					double price = 0d;
					double annualTaxes = 0d;
					double monthlyFee = 0d;
					int leasePeriod = 0;
					double condMonthlyFee = 0d;
					if (option.charAt(0) == 'a' || option.charAt(0) == 'A') {
						setNumber = false;
						System.out.println("Enter purchase price of the house");
						do {
							setNumber = true;
							try {
								String reqInput = input.nextLine();
								if (reqInput.equalsIgnoreCase("quit") || reqInput.equalsIgnoreCase("abort")) {
									setAbort = true;
									break;
								}
								price = Double.parseDouble(reqInput);
							} catch (Exception e) {
								setNumber = false;
								System.out.println("Incorrect input. Value must be number. Enter again.");
							}
						} while (setNumber != true);
						if (setAbort)
							continue;

						setNumber = false;
						System.out.println("Enter annual amount of taxes for the house");
						do {
							setNumber = true;
							try {
								String reqInput = input.nextLine();
								if (reqInput.equalsIgnoreCase("quit") || reqInput.equalsIgnoreCase("abort")) {
									setAbort = true;
									break;
								}
								annualTaxes = Double.parseDouble(reqInput);
							} catch (Exception e) {
								setNumber = false;
								System.out.println("Incorrect input. Value must be number. Enter again.");
							}
						} while (setNumber != true);
						if (setAbort)
							continue;

					} else if (option.charAt(0) == 'b' || option.charAt(0) == 'B') {
						setNumber = false;
						System.out.println("Enter purchase price of the condominium");
						do {
							setNumber = true;
							try {
								String reqInput = input.nextLine();
								if (reqInput.equalsIgnoreCase("quit") || reqInput.equalsIgnoreCase("abort")) {
									setAbort = true;
									break;
								}
								price = Double.parseDouble(reqInput);
							} catch (Exception e) {
								setNumber = false;
								System.out.println("Incorrect input. Value must be number. Enter again.");
							}
						} while (setNumber != true);
						if (setAbort)
							continue;

						setNumber = false;
						System.out.println("Enter annual amount of taxes for the condominium");
						do {
							setNumber = true;
							try {
								String reqInput = input.nextLine();
								if (reqInput.equalsIgnoreCase("quit") || reqInput.equalsIgnoreCase("abort")) {
									setAbort = true;
									break;
								}
								annualTaxes = Double.parseDouble(reqInput);
							} catch (Exception e) {
								setNumber = false;
								System.out.println("Incorrect input. Value must be number. Enter again.");
							}
						} while (setNumber != true);
						if (setAbort)
							continue;

						setNumber = false;
						System.out.println("Enter monthly management fee charged by the condominium association");
						do {
							setNumber = true;
							try {
								String reqInput = input.nextLine();
								if (reqInput.equalsIgnoreCase("quit") || reqInput.equalsIgnoreCase("abort")) {
									setAbort = true;
									break;
								}
								condMonthlyFee = Double.parseDouble(reqInput);
							} catch (Exception e) {
								setNumber = false;
								System.out.println("Incorrect input. Value must be number. Enter again.");
							}
						} while (setNumber != true);
						if (setAbort)
							continue;
					} else {

						setNumber = false;
						System.out.println("Enter the monthly rent of the apartment");
						do {
							setNumber = true;
							try {
								String reqInput = input.nextLine();
								if (reqInput.equalsIgnoreCase("quit") || reqInput.equalsIgnoreCase("abort")) {
									setAbort = true;
									break;
								}
								monthlyFee = Double.parseDouble(reqInput);
							} catch (Exception e) {
								setNumber = false;
								System.out.println("Incorrect input. Value must be number. Enter again.");
							}
						} while (setNumber != true);
						if (setAbort)
							continue;

						setNumber = false;
						System.out.println("Enter lease period for the apartment");
						do {
							setNumber = true;
							try {
								String reqInput = input.nextLine();
								if (reqInput.equalsIgnoreCase("quit") || reqInput.equalsIgnoreCase("abort")) {
									setAbort = true;
									break;
								}
								leasePeriod = Integer.parseInt(reqInput);
							} catch (Exception e) {
								setNumber = false;
								System.out.println("Incorrect input. Value must be number. Enter again.");
							}
						} while (setNumber != true);
						if (setAbort)
							continue;
					}
                      // prints House details
					if (option.charAt(0) == 'a' || option.charAt(0) == 'A') {
						House property = new House();
						property.setAddress(address);
						property.setCity(city);
						property.setState(state);
						property.setZipcode(zipcode);
						property.setNoOfBedrooms(noOfBedrooms);
						property.setNoOfBathrooms(noOfBathrooms);
						property.setPrice(price);
						property.setAnnualTaxes(annualTaxes);

						listOfHouses.add(property);
						
						// prints condo details
					} else if (option.charAt(0) == 'b' || option.charAt(0) == 'B') {
						Condominium property = new Condominium();
						property.setAddress(address);
						property.setCity(city);
						property.setState(state);
						property.setZipcode(zipcode);
						property.setNoOfBedrooms(noOfBedrooms);
						property.setNoOfBathrooms(noOfBathrooms);
						property.setPrice(price);
						property.setAnnualTaxes(annualTaxes);
						property.setMonthlyFee(condMonthlyFee);
						listOfCondominium.add(property);
						
						// // prints apartment details
					} else {
						Apartment property = new Apartment();
						property.setAddress(address);
						property.setCity(city);
						property.setState(state);
						property.setZipcode(zipcode);
						property.setNoOfBedrooms(noOfBedrooms);
						property.setNoOfBathrooms(noOfBathrooms);
						property.setMonthlyFee(monthlyFee);
						property.setLeasePeriod(leasePeriod);

						listOfApartment.add(property);
					}
				}
			} else {
				System.out.println("Invalid choice..! Try again..!");
			}

			if (setQuit) {
				break;
			}
		} while (setChoice != false);

		input.close(); // Close Scanner objects

		System.out.println("Thank you for using Real Estate Management Application");
	}
}